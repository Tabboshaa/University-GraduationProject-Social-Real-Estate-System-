<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Main_Type extends Model
{
    //
    protected $primaryKey='Main_Type_Id';
    protected $fillable=[
        'Main_Type_Name'
        ];
}
