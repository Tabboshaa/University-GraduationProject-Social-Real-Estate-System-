<?php

namespace App\Http\Controllers;

use App\Phone_Numbers;
use Illuminate\Http\Request;

class PhoneNumbersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Phone_Numbers  $phone_Numbers
     * @return \Illuminate\Http\Response
     */
    public function show(Phone_Numbers $phone_Numbers)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Phone_Numbers  $phone_Numbers
     * @return \Illuminate\Http\Response
     */
    public function edit(Phone_Numbers $phone_Numbers)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Phone_Numbers  $phone_Numbers
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Phone_Numbers $phone_Numbers)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Phone_Numbers  $phone_Numbers
     * @return \Illuminate\Http\Response
     */
    public function destroy(Phone_Numbers $phone_Numbers)
    {
        //
    }
}
