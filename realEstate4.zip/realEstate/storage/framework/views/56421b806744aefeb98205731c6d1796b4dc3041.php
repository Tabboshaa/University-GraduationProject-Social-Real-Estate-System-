
<?php $__env->startSection('Item_Main_Type_table'); ?>

    <table id="datatable" class="table table-striped table-bordered dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="datatable_info">
        <thead>
        <tr>
            <th>User</th>
            <td><?php echo e($user[0]->First_Name); ?> <?php echo e($user[0]->Middle_Name); ?> <?php echo e($user[0]->Last_Name); ?></td>

        </tr>
        </thead>
        <tbody>
        <tr>
            <th>Location</th>
            <td><?php echo e($Location->Country_Name); ?>,<?php echo e($Location->State_Name); ?>,<?php echo e($Location->City_Name); ?>,<?php echo e($Location->Region_Name); ?>,<?php echo e($Location->Street_Name); ?></td>
        </tr>
        <tr>
            <td colspan="2" style="text-align:center">Details</td>
        </tr>
        <tr>
            
            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $properties => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <table class="table table-striped table-bordered dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="datatable_info">

                <thead>
                <tr>
                    <th colspan="<?php echo e(count($details)+1); ?>" style="text-align:center"><?php echo e($properties); ?></th>
                </tr>
                <tr >

                    <th><?php echo e($properties); ?> Number</th>

                    
                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($detail->Detail_Name); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    


                </tr>
                </thead>
                <tbody>

                    
                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($detail->Property_Name); ?> </td>

                        
                        <!-- <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> -->
                        <td><?php echo e($detail->DetailValue); ?></td>
                        <!-- <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                        

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                </tbody>
            </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
        </tr>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.backend.database pages.Item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GP\realEstate\resources\views/website/backend/database pages/ShowItem.blade.php ENDPATH**/ ?>