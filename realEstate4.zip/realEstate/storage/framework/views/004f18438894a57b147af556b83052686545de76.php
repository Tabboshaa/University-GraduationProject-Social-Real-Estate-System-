
<?php $__env->startSection('test'); ?>
<table id="datatable" class="table table-striped table-bordered dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="datatable_info">
                            <thead>
                                <tr>
                                    <th>Main Type ID</th>
                                    <th>Type Name</th>
                                    <th> <a href="">Select all</a>
                                    <th></th>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- EL FOREARCH HNA -->
                                <?php $__currentLoopData = $main_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($main_type->Main_Type_Id); ?></td>
                                    <td><?php echo e($main_type->Main_Type_Name); ?></td>
                                    <td><input type='checkbox'></td>
                                    <td><i class="fa fa-edit"></i></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- END OF FOREACH -->
                            </tbody>
                        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.backend.database pages.Main_Types', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realEstate\resources\views/website/backend/database pages/test.blade.php ENDPATH**/ ?>