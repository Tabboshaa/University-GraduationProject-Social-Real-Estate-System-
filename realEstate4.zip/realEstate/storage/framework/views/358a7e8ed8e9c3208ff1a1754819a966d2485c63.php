
<?php $__env->startSection('Item_Main_Type_table'); ?>

<?php echo $__env->make('website\backend\database pages\Test1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php $__env->stopSection(); ?>
<?php echo $__env->make('website.backend.database pages.Item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GP\realEstate\resources\views/website\backend/database pages/Test.blade.php ENDPATH**/ ?>