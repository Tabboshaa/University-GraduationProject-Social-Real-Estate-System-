
<?php $__env->startSection('Item_Main_Type_table'); ?>

<link href="<?php echo e(asset('css/ShowItem.css')); ?>" rel="stylesheet" type="text/css" />


<div class="C">
    
    <h2><?php echo e($user[0]->First_Name); ?> <?php echo e($user[0]->Middle_Name); ?> <?php echo e($user[0]->Last_Name); ?> Items </h2> 
    
</div>

<table id="datatable" class="table  pro  dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="datatable_info">
    <thead>
        <tr>   
            <td class="th1">User</td>
            <td class="td1"> 
                 Name : <?php echo e($user[0]->First_Name); ?> <?php echo e($user[0]->Middle_Name); ?> <?php echo e($user[0]->Last_Name); ?> 
                <br>Email :<?php echo e($email); ?> <a href="<?php echo e(url('/edit_item_user/'.$item_id)); ?>"><i class="fa fa-edit"> Edit</i></a>
                <br>Phone Number :<?php echo e($phone_number); ?>

            </td>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th class="th1">Location</th>
            <td class="td1"><?php echo e($Location->Country_Name); ?>,<?php echo e($Location->State_Name); ?>,<?php echo e($Location->City_Name); ?>,<?php echo e($Location->Region_Name); ?>,<?php echo e($Location->Street_Name); ?>

            <a href="<?php echo e(url('/edit_item_location/'.$item_id)); ?>"><i class="fa fa-edit"> Edit</i>
            </td>
        </tr>

        <tr>
            <form method="Post" action="<?php echo e(url('/delete_detail_item?_method=delete')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <table class="table pro2 table-bordered dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="datatable_info">

                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="th2">
                            <h4><?php echo e($property); ?> detail</h4>
                        </td>
                        <th class="th2">value</th>
                        <th class="th2">Select all <input type="checkbox" id="selectAll" name="selectAll"> </a>  <button class="btn"><i class="fa fa-trash" style="margin-right:155px;"></i></th>
                        <th class="th2">Edit</th>
                        <!-- Java Script for select all function -->
                        <script>
                            document.getElementById('selectAll').onclick = function() {
                                var checkboxes = document.getElementsByName('id[]'); //get all check boxes with name delete
                                for (var checkbox of checkboxes) { //for loop to set all checkboxes to checked
                                    checkbox.checked = this.checked;
                                }
                            }
                        </script>

                    </tr>

                    <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr  class="ha">
                        <td>
                            <h6><?php echo e($detailValue->Detail_Name); ?></h6>
                        </td>
                        <td>
                            <h6><?php echo e($detailValue->DetailValue); ?></h6>
                        </td>
                        <td><input type="checkbox" name="id[]" value="<?php echo e($detailValue->Detail_Id); ?>"></td>
                        <td><a href="javascript:void(0)" onclick="setDetailIdName('<?php echo e($detailValue->Detail_Id); ?>','<?php echo e($detailValue->DetailValue); ?>')"><i class="fa fa-edit"></i></a></td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </form>
        </tr>
    </tbody>
</table>



<?php if(!empty($subtypeid)): ?>
<a href="<?php echo e(url('/property_select/'.$item_id.'/'.$subtypeid.'')); ?>" id="btun1"class="btn btn-info "> Add More Details</a>
<?php else: ?> 
<a href="<?php echo e(url('/addItemSteps/'.$item_id)); ?>" class="btn btn-info"id="btun1" > Add Details of item</a>

<?php endif; ?>
<a href="<?php echo e(url('/Details')); ?>" class="btn btn-info" id="btun3">Search for an Item</a>
<a href="<?php echo e(url('/Item')); ?>" class="btn btn-info" id="btun2"> Create Another Item</a>
<form method="Post" action="<?php echo e(url('/DelteItem/'.$item_id.'?_method=delete')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
<button type="submit" class="btn btn-danger" id="btun4"> Delete Item</button>
</form>
<div class="modal fade" id="EditDetailModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Sub Type</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="EditDetailForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="id">

                    <div class="form-group">
                        <label for="DetailName"  style="font-size: 12pt">Detail Value</label>
                        <input type="text" style="border-radius: 3pt" name="DetailName" id="DetailName" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-success" id="btun5">Edit</button>
                </form>

            </div>
        </div>
    </div>
</div>

<script>
    function setDetailIdName(id, name) {

        $("#id").val(id);
        $("#DetailName").val(name);
        $("#EditDetailModal").modal("toggle");
    }

    $('#EditDetailForm').submit(function() {

        var id = $("#id").val();
        // var MainTypeid=$("#MainTypeNameEdit").val();
        var DetailName = $("#DetailName").val();
        var _token = $("input[name=_token]").val();

        $.ajax({
            url: "<?php echo e(route('Detail.update')); ?>",
            Type: "PUT",
            data: {
                id: id,
                // MainTypeid:MainTypeid,
                DetailName: DetailName,
                _token: _token
            },
            success: function() {
                console.log('Success');
                $("#EditDetailModal").modal("toggle");
                // $("#EditDetailModal")[0].reset();
            },
            error: function() {
                console.log('Error');
            }

        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.backend.database pages.Item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GP\realEstate\resources\views/website/backend/database pages/omniaShowItem.blade.php ENDPATH**/ ?>