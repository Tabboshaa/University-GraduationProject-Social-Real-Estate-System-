
<?php $__env->startSection('content'); ?>
<div class="right_col" role="main">
    <div class="title_right">
        <div class="x_panel">
            <form method="POST" action="<?php echo e(url('/add_street')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <!-- Add Country-->
                <div class="form-group row">
                    <label for="Country Name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Country Name')); ?></label>

                    <div class="col-md-2">
                        <select id="Country_Name" class="form-control <?php $__errorArgs = ['Country Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Country_Name" value="<?php echo e(old('Country Name')); ?>" required autocomplete="Country Name">
                            <!--  For loop  -->
                            <?php $__currentLoopData = $counrty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counrty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($counrty->Country_Id); ?>"><?php echo e($counrty->Country_Name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- End loop -->
                        </select>
                        <?php $__errorArgs = ['Country Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- Add State-->
                <div class="form-group row">
                    <label for="State Name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('State Name')); ?></label>

                    <div class="col-md-2">
                        <select id="State Name" class="form-control <?php $__errorArgs = ['State Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="State_Name" value="<?php echo e(old('State Name')); ?>" required autocomplete="State Name">
                            <!--  For loop  -->
                            <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($state->State_Id); ?>"><?php echo e($state->State_Name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- End loop -->
                        </select>
                        <?php $__errorArgs = ['State Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- Add City-->
                <div class="form-group row">
                    <label for="City Name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('City Name')); ?></label>

                    <div class="col-md-2">
                        <select id="City Name" class="form-control <?php $__errorArgs = ['City Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="City_Name" value="<?php echo e(old('City Name')); ?>" required autocomplete="City Name">
                            <!--  For loop  -->
                            <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($city->City_Id); ?>"><?php echo e($city->City_Name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- End loop -->
                        </select>
                        <?php $__errorArgs = ['City Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- Add Region-->
                <div class="form-group row">
                    <label for="Region Name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Region Name')); ?></label>

                    <div class="col-md-2">
                        <select id="Region Name" class="form-control <?php $__errorArgs = ['Region Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Region_Name" value="<?php echo e(old('Region Name')); ?>" required autocomplete="Region Name">
                            <!--  For loop  -->
                            <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($region->Region_Id); ?>"><?php echo e($region->Region_Name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- End loop -->
                        </select>
                        <?php $__errorArgs = ['Region Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- Add New Street -->
                <div class="form-group row">
                    <label for="Street Name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Street Name :')); ?></label>
                    <div class="col-md-2">
                        <input id="Street Name" type="text" class="form-control <?php $__errorArgs = ['Street Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Street_Name" value="<?php echo e(old('Street Name')); ?>" required autocomplete="Street Name" autofocus>

                        <?php $__errorArgs = ['Street Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <div class="form-group row mb-0">
                    <div class="col-md-2 offset-md-2">
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Add')); ?>

                        </button>
                        <a href="<?php echo e(url('/show_street')); ?>" class="btn btn-primary"><?php echo e(__('Show')); ?></a>
                    </div>
                </div>
            </form>
        </div>
        <div class="x_panel">
            <div id="datatable_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap no-footer">
                <div class="row">
                <?php echo $__env->yieldContent('table'); ?>
                </div>
                <div class="row">
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realEstate\resources\views/website/backend/database pages/Add_Street.blade.php ENDPATH**/ ?>