
<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/ButtonStyle.css')); ?>" rel="stylesheet" type="text/css" />

    <div class="right_col" role="main">
        <div class="title_right">
            <div class="x_panel">
                
            <?php echo $__env->make('website.backend.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form method="POST" action="<?php echo e(url('/add_country')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <!-- Add New Country -->
                    <div class="form-group row">
                        <label for="country_name" class="col-md-2 col-form-label text-md-right" style="font-size: 12pt">
                            <?php echo e(__('Country :')); ?>

                        </label>
                            <div class="col-md-2">
                                <input id="country_name" style="border-radius: 3pt" type="text" class="form-control <?php $__errorArgs = ['country_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="country_name" value="<?php echo e(old('country_name')); ?>" required autocomplete="country_name" autofocus>

                                    <?php $__errorArgs = ['country_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      
                            </div>
                    </div>
                    <div class="form-group row mb-0">
                        <div class="col-md-2 offset-md-2">
                            <button type="submit" id="btun1"class="btn btn-primary">
                                <?php echo e(__('Add')); ?>

                            </button>
</form>
<button id="btun2"  class="btn btn-primary">
                                <a href="<?php echo e(url('/show_country')); ?>" class="link2" ><?php echo e(__('Show')); ?></a>
                            </button>
                        </div>
                    </div>
             
                
            </div>
            <div class="x_panel">
            <div id="datatable_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap no-footer">
                <div class="row">
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <?php echo $__env->yieldContent('table'); ?>
                    </div>
                </div>
                <div class="row">
                </div>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GP\realEstate\resources\views/website/backend/database pages/Add_Country.blade.php ENDPATH**/ ?>