
<?php $__env->startSection('table'); ?>

<form method="Post" action="<?php echo e(url('/delete_main_type?_method=delete')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
<table id="datatable" class="table table-striped table-bordered dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="datatable_info">
    <thead>
        <tr>
            
            <th>Type Name</th>
            <th>Select all <input type="checkbox" id="selectAll" name="selectAll">  <input type="submit" value="Delete Selected" class="btn btn-secondary"></th>
            <th></th>
            <!-- Java Script for select all function -->
                <script>
                    document.getElementById('selectAll').onclick = function() {
                        var checkboxes = document.getElementsByName('mainType'); //get all check boxes with name delete
                        for (var checkbox of checkboxes) { //for loop to set all checkboxes to checked
                            checkbox.checked = this.checked;
                        }
                    }
                </script>
        </tr>
    </thead>
    <tbody>
        <!-- EL FOREARCH HNA -->


        <?php $__currentLoopData = $main_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($main_type->Main_Type_Name); ?></td>
            <td><input type="checkbox" name="mainType[]" value="<?php echo e($main_type->Main_Type_Id); ?>"></td>
             
         <td><a href="javascript:void(0)" onclick="setMainTypeIdName('<?php echo e($main_type->Main_Type_Id); ?>','<?php echo e($main_type->Main_Type_Name); ?>')"><i class="fa fa-edit"> Edit</i></a></td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       
                <!-- END OF FOREACH -->
    </tbody>
</table>
</form>

<div class="modal fade" id="EditMainTypeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Sub Type</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="EditSubTypeForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="id">
          
                    <div class="form-group">
                        <label for="MainTypeName" >Main Type Name</label>
                        <input type="text" name="MainTypeName" id="MainTypeName" class="form-control">
                        
                    </div>
                    <button  type="submit" class="btn btn-success">Edit</button>
                </form>

            </div>
        </div>
    </div>
</div>

    <script>
        function setMainTypeIdName(id,name){

                $("#id").val(id);
                $("#MainTypeName").val(name);
                $("#EditMainTypeModal").modal("toggle");
        }
        $('#EditSubTypeForm').submit(function (){

            var id=$("#id").val();
            var MainTypeName=$("#MainTypeName").val();
            var _token= $("input[name=_token]").val();
            
            $.ajax({
                url:"<?php echo e(route('Maintype.update')); ?>",
                Type:"PUT",
                data:{
                    id:id,
                    // MainTypeid:MainTypeid,
                    MainTypeName:MainTypeName,
                     _token:_token
                },
                success:function (response){
                    console.log('Success')
                    console.log(response);
                    // $('#sid'+response.id + 'td:nth-child(1)').text(response.MainTypeName);
                    $("#EditMainTypeModal").modal("toggle");
                    // $("#EditMainTypeModal")[0].reset();
                },
                error:function ()
                {
                    console.log('Error');
                }

            });
        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.backend.database pages.Main_Types', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realEstate\resources\views/website/backend/database pages/Main_Types_Show.blade.php ENDPATH**/ ?>