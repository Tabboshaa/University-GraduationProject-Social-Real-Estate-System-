<?php $__env->startSection('Property_Details_table'); ?>
    <div class="row">
        <div class="col-sm-12">
            <table id="datatable" class="table table-striped table-bordered dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="datatable_info">
                <thead>
                <tr>
                    <th>Main Type</th>
                    <th>Sub Type</th>
                    <th>Property</th>
                    <th>Property Detail Name</th>
                    <th>Select all <input type="checkbox" id="selectAll" name="selectAll"> <a href="#/trash">  </a></th>
                    <th></th>
                    <!-- Java Script for select all function -->
                    <script>
                        document.getElementById('selectAll').onclick = function() {
                            var checkboxes = document.getElementsByName('id[]'); //get all check boxes with name delete
                            for (var checkbox of checkboxes) { //for loop to set all checkboxes to checked
                                checkbox.checked = this.checked;
                            }
                        }
                    </script>
                </tr>
                </thead>
                <tbody>
                <!-- EL FOREARCH HNA -->
                <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="Post" action="<?php echo e(url('/delete_property_detail/'.$property_detail->Property_Detail_Id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                    <tr>
                        <td><?php echo e($property_detail->Main_Type_Name); ?></td>
                        <td><?php echo e($property_detail->Sub_Type_Name); ?></td>
                        <td><?php echo e($property_detail->Property_Name); ?></td>
                        <td><?php echo e($property_detail->Detail_Name); ?></td>
                        <td><input type="checkbox" name="id[]" value="<?php echo e($property_detail->Property_Detail_Id); ?>"></td>
                         <input type="hidden" name="_method" value="DELETE">
                        <td><a href="javascript:void(0)" onclick="setPropertyDetailIdName('<?php echo e($property_detail->Property_Detail_Id); ?>','<?php echo e($property_detail->Detail_Name); ?>')"><i class="fa fa-edit"> Edit</i></a></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- END OF FOREACH -->
                <td><input type="submit" value="Delete Selected"></td>
                </form>
                </tbody>
            </table>
        </div>
    </div>
    <div class="modal fade" id="EditPropertyDetailModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Sub Type</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="EditSubTypeForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="id">
          
                    <div class="form-group">
                        <label for="PropertyDetailName" >Detail Name</label>
                        <input type="text" name="PropertyDetailName" id="PropertyDetailName" class="form-control">
                    </div>
                    <button  type="submit" class="btn btn-success">Edit</button>
                </form>

            </div>
        </div>
    </div>
</div>

    <script>
        function setPropertyDetailIdName(id,name){

                $("#id").val(id);
                $("#PropertyDetailName").val(name);
                $("#EditPropertyDetailModal").modal("toggle");
        }
        $('#EditSubTypeForm').submit(function (){

            var id=$("#id").val();
            // var MainTypeid=$("#MainTypeNameEdit").val();
            var PropertyDetailName=$("#PropertyDetailName").val();
            var _token= $("input[name=_token]").val();
            
            $.ajax({
                url:"<?php echo e(route('propertyDetail.update')); ?>",
                Type:"PUT",
                data:{
                    id:id,
                    // MainTypeid:MainTypeid,
                    PropertyDetailName:PropertyDetailName,
                     _token:_token
                },
                success:function (response){
                    console.log('Success')
                    console.log(response);
                    // $('#sid'+response.id + 'td:nth-child(1)').text(response.PropertyDetailName);
                    $("#EditPropertyDetailModal").modal("toggle");
                    // $("#EditPropertyDetailModal")[0].reset();
                },
                error:function ()
                {
                    console.log('Error');
                }

            });
        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.backend.database pages.Property_Details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realEstate\resources\views/website/backend/database pages/Property_Details_Show.blade.php ENDPATH**/ ?>