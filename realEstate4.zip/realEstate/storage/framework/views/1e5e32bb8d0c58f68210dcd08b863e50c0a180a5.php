<?php $__env->startSection('content'); ?>
<script type="text/javascript">

    $(document).ready(function (){

        $(document).on('change','#MainTypeName',function(){

            var MainType_id=$(this).val();
            console.log(MainType_id);
            var FormTag= $(this).parent().parent().parent(); //first div, second div , form
            var op=" ";
            $.ajax({
                type:'get',
                url:"<?php echo e(url('/findSub')); ?>",
                data:{'id':MainType_id},
                success:function(data){
                    console.log('success');

                    op+='<option value="0" selected disabled>Select Sub Type</option>';
                    Object.values(data).forEach(val => {
                        console.log(val);
                        op+='<option value="'+val['Sub_Type_Id']+'">'+val['Sub_Type_Name']+'</option>';
                    });
                    FormTag.find('#SubTypeProperty').html("");
                    FormTag.find('#SubTypeName').html("");
                    FormTag.find('#SubTypeName').append(op);
                },
                error:function(){
                    console.log('error');
                }
            });
        });
        $(document).on('change','#SubTypeName',function(){

var SupType_id=$(this).val();
console.log(SupType_id);
var FormTag= $(this).parent().parent().parent(); //first div, second div , form
var op=" ";
$.ajax({
    type:'get',
    url:"<?php echo e(url('/findProperty')); ?>",
    data:{'id':SupType_id},
    success:function(data){
        console.log('success');

        op+='<option value="0" selected disabled>Select Property Name</option>';
        Object.values(data).forEach(val => {
            console.log(val);
            op+='<option value="'+val['Property_Id']+'">'+val['Property_Name']+'</option>';
        });

        FormTag.find('#SubTypeProperty').html("");
        FormTag.find('#SubTypeProperty').append(op);
    },
    error:function(){
        console.log('error');
    }
});
});
// 
$(document).on('change','#SubTypeProperty',function(){

var SupTypeProperty_id=$(this).val();
console.log(SupTypeProperty_id);
var FormTag= $(this).parent().parent().parent(); //first div, second div , form
var op=" ";
$.ajax({
    type:'get',
    url:"<?php echo e(url('/findPropertyDetail')); ?>",
    data:{'id':SupTypeProperty_id},
    success:function(data){
        console.log('success');

        op+='<option value="0" selected disabled>Select Detail</option>';
        Object.values(data).forEach(val => {
            console.log(val);
            op+='<option value="'+val['Property_Detail_Id']+'">'+val['Detail_Name']+'</option>';
        });

        FormTag.find('#PropertyDetail').html("");
        FormTag.find('#PropertyDetail').append(op);
    },
    error:function(){
        console.log('error');
    }
});
});

    });
    $(document).ready(function (){

       
    });


</script>
    <div class="right_col" role="main">
        <div class="title_right">
            <div class="x_panel">
                <form method="POST" action="<?php echo e(url('/add_Details')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- Item -->
                    <div class="form-group row">
                        <label for="Item" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Item')); ?></label>

                        <div class="col-md-2">
                            <select id="Item" class="form-control <?php $__errorArgs = ['Item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Item" value="<?php echo e(old('Item')); ?>" required autocomplete="Item">
                                <!--  For loop  -->
                                
                                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->Item_Id); ?>"><?php echo e($item->Item_Id); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- End loop -->
                            </select>
                            <?php $__errorArgs = ['Item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- Main Type -->
                    <div class="form-group row">
                        <label for="Main Type Name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Main Type Name')); ?></label>

                        <div class="col-md-2">
                            <select id="MainTypeName" class="form-control <?php $__errorArgs = ['Main Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Main_Type_Name" value="<?php echo e(old('Main Type Name')); ?>" required autocomplete="Main Type Name">
                                <!--  For loop  -->
                                <option value="0" selected disabled>Select Main Type</option>
                                <?php $__currentLoopData = $main_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($main_type->Main_Type_Id); ?>"><?php echo e($main_type->Main_Type_Name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- End loop -->
                            </select>
                            <?php $__errorArgs = ['Main Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="Sub Type Name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Sub Type Name')); ?></label>

                        <div class="col-md-2">
                            <select id="SubTypeName" class="form-control <?php $__errorArgs = ['Sub Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Sub_Type_Name" value="<?php echo e(old('Sub Type Name')); ?>" required autocomplete="Sub Type Name">
                                <!--  For loop  -->
                               
                            <!-- End loop -->
                            </select>
                            <?php $__errorArgs = ['Sub Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="Sub_Type_Property" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Sub Type Property')); ?></label>

                        <div class="col-md-2">
                            <select id="SubTypeProperty" class="form-control <?php $__errorArgs = ['Sub_Type_Property'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Sub_Type_Property" value="<?php echo e(old('Sub_Type_Property')); ?>" required autocomplete="Sub_Type_Property">
                                <!--  For loop  -->
                                <!-- <option value="0" selected disabled>Select Property Name</option> -->
                            <!-- End loop -->
                            </select>
                            <?php $__errorArgs = ['Sub Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="PropertyDetail" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Property Detail')); ?></label>

                        <div class="col-md-2">
                            <select id="PropertyDetail" class="form-control <?php $__errorArgs = ['Propety_Detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Propety_Detail" value="<?php echo e(old('Propety_Detail')); ?>" required autocomplete="Propety_Detail">
                                <!--  For loop  -->
                                <!-- <option value="0" selected disabled>Select Property Name</option> -->
                            <!-- End loop -->
                            </select>
                            <?php $__errorArgs = ['Propety_Detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="DetailValue" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Detail Value')); ?></label>

                        <div class="col-md-2">
                            <input id="DetailValue" type="text" class="form-control <?php $__errorArgs = ['DetailValue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="DetailValue" value="<?php echo e(old('DetailValue')); ?>" required autocomplete="DetailValue" autofocus>

                            <?php $__errorArgs = ['DetailValue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-2 offset-md-2">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Add')); ?>

                            </button>
                            <a href="<?php echo e(url('/Details_show')); ?>" class="btn btn-primary"> <?php echo e(__('Show')); ?></a>
                        </div>
                    </div>
                </form>
            </div>
            <div class="x_panel">
                <div id="datatable_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap no-footer">
                    <div class="row">
                    </div>
                    <?php echo $__env->yieldContent('Details_table'); ?>

                    <div class="row">
                    </div>
                </div>
            </div>

        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realEstate\resources\views/website/backend/database pages/Details.blade.php ENDPATH**/ ?>