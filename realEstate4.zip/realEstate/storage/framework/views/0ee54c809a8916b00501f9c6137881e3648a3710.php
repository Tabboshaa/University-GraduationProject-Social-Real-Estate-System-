
<?php $__env->startSection('table'); ?>
<table id="datatable" class="table table-striped table-bordered dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="datatable_info">
    <thead>
        <tr>
            <th>Region Id</th>
            <th>Country Id</th>
            <th>State Id</th>
            <th>City Id</th>
            <th>Region Name</th>
            <th>Select all <input type="checkbox" id="selectAll" name="selectAll"> <a href="#/trash"> <i class="fa fa-trash" style="width:20%;height:20%;text-align: right;"></i></a></th>
            <th></th>
            <!-- Java Script for select all function -->
            <script>
                document.getElementById('selectAll').onclick = function() {
                    var checkboxes = document.getElementsByName('delete'); //get all check boxes with name delete
                    for (var checkbox of checkboxes) { //for loop to set all checkboxes to checked
                        checkbox.checked = this.checked;
                    }
                }
            </script>
        </tr>
    </thead>
    <tbody>
        <!-- EL FOREARCH HNA -->
        <?php $__currentLoopData = $region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($region->Region_Id); ?></td>
            <td><?php echo e($region->Country_Id); ?></td>
            <td><?php echo e($region->State_Id); ?></td>
            <td><?php echo e($region->City_Id); ?></td>
            <td><?php echo e($region->Region_Name); ?></td>
            <td><input type="checkbox" name="delete"></td>
            <td><i class="fa fa-edit"></i></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- END OF FOREACH -->
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.backend.database pages.Add_Region', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realEstate\resources\views/website/backend/database pages/Add_Region_Show.blade.php ENDPATH**/ ?>