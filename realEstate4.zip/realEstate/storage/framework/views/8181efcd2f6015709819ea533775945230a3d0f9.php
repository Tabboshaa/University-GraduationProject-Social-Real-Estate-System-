<footer>
    <div class="pull-right">
        Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
    </div>
    <div class="clearfix"></div>
</footer>
<?php /**PATH C:\xampp\htdocs\realEstate\resources\views/website/backend/layouts/footer.blade.php ENDPATH**/ ?>