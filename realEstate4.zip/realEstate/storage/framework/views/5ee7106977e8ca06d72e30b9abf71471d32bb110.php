
<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/ButtonStyle.css')); ?>" rel="stylesheet" type="text/css" />

<script type="text/javascript">

    $(document).ready(function (){

        $(document).on('change','#MainTypeName',function(){


            var MainType_id=$(this).val();
            console.log(MainType_id);
            var FormTag= $(this).parent().parent().parent(); //first div, second div , form
            var op=" ";
            $.ajax({
                type:'get',
                url:"<?php echo e(url('/findSub')); ?>",
                data:{'id':MainType_id},
                success:function(data){
                    console.log('success');

                    op+='<option value="0" selected disabled>Select Sub Type</option>';
                    Object.values(data).forEach(val => {
                        console.log(val);
                        op+='<option value="'+val['Sub_Type_Id']+'">'+val['Sub_Type_Name']+'</option>';
                    });
                    FormTag.find('#SubTypeProperty').html("");
                    FormTag.find('#SubTypeName').html("");
                    FormTag.find('#SubTypeName').append(op);
                },
                error:function(){
                    console.log('error');
                }
            });
        });
    });
    $(document).ready(function (){

        $(document).on('change','#SubTypeName',function(){

            var SupType_id=$(this).val();
            console.log(SupType_id);
            var FormTag= $(this).parent().parent().parent(); //first div, second div , form
            var op=" ";
            $.ajax({
                type:'get',
                url:"<?php echo e(url('/findProperty')); ?>",
                data:{'id':SupType_id},
                success:function(data){
                    console.log('success');

                    op+='<option value="0" selected disabled>Select Property Name</option>';
                    Object.values(data).forEach(val => {
                        console.log(val);
                        op+='<option value="'+val['Property_Id']+'">'+val['Property_Name']+'</option>';
                    });

                    FormTag.find('#SubTypeProperty').html("");
                    FormTag.find('#SubTypeProperty').append(op);
                },
                error:function(){
                    console.log('error');
                }
            });
        });

    });


</script>
    <div class="right_col" role="main">
        <div class="title_right">
            <div class="x_panel">
            <?php echo $__env->make('website.backend.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form method="POST" action="<?php echo e(url('/add_Property_Details')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- Main Type -->
                    <div class="form-group row">
                        <label for="Main Type Name" class="col-md-2 col-form-label text-md-right" style="font-size: 12pt">
                            <?php echo e(__('Main Type :')); ?>

                        </label>

                        <div class="col-md-2">
                            <select id="MainTypeName" style="border-radius: 3pt" class="form-control <?php $__errorArgs = ['Main Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Main_Type_Name" value="<?php echo e(old('Main Type Name')); ?>" required autocomplete="Main Type Name">
                                <option value="0" selected disabled>Select Main Type</option>;
                                 <!-- For loop  --> 
                                 <?php $__currentLoopData = $main_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($main_type->Main_Type_Id); ?>"><?php echo e($main_type->Main_Type_Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- End loop -->
                            </select>
                            <?php $__errorArgs = ['Main Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
<!-- Sub Type -->
                    <div class="form-group row">
                        <label for="Sub Type Name" class="col-md-2 col-form-label text-md-right" style="font-size: 12pt">
                            <?php echo e(__('Sub Type :')); ?>

                        </label>

                        <div class="col-md-2">
                            <select id="SubTypeName" style="border-radius: 3pt" class="form-control <?php $__errorArgs = ['Sub Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Sub_Type_Name" value="<?php echo e(old('Sub Type Name')); ?>" required autocomplete="Sub Type Name">
                               <!--  For loop  -->
                               <!-- <option value="0" selected disabled>Select Sub Type</option> -->
                            <!-- End loop -->
                            </select>
                            <?php $__errorArgs = ['Sub Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!-- Property -->
                    <div class="form-group row">
                        <label for="Sub_Type_Property" class="col-md-2 col-form-label text-md-right" style="font-size: 12pt">
                            <?php echo e(__('Sub Type Property :')); ?>

                        </label>

                        <div class="col-md-2">
                            <select id="SubTypeProperty" style="border-radius: 3pt" class="form-control <?php $__errorArgs = ['Sub_Type_Property'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Sub_Type_Property" value="<?php echo e(old('Sub_Type_Property')); ?>" required autocomplete="Sub_Type_Property">
                                <!--  For loop  -->
                                <!-- <option value="0" selected disabled>Select Property Name</option> -->
                            <!-- End loop -->
                            </select>
                            <?php $__errorArgs = ['Sub Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="Sub Type Name" class="col-md-2 col-form-label text-md-right" style="font-size: 12pt">
                            <?php echo e(__('Detail :')); ?>

                        </label>

                        <div class="col-md-2">
                            <input id="Detail" style="border-radius: 3pt" type="text" class="form-control <?php $__errorArgs = ['Detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="property_details" value="<?php echo e(old('Detail')); ?>" required autocomplete="Detail" autofocus>

                            <?php $__errorArgs = ['Detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                  
 <!-- Data Type -->

    <label for="Data Type Name" class="col-md-2 col-form-label text-md-right" style="font-size: 12pt">
        <?php echo e(__('Data Type :')); ?>

    </label>

    <div class="col-md-2">
        <select id="DataTypeName" style="border-radius: 3pt" class="form-control <?php $__errorArgs = ['Data Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Data_Type_Name" value="<?php echo e(old('Data Type Name')); ?>" required autocomplete="Data Type Name">
            <option value="0" selected disabled>Select Data Type</option>;
             <!-- For loop  --> 
             <?php $__currentLoopData = $data_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($data_type->id); ?>"><?php echo e($data_type->datatype); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- End loop -->
        </select>
        <?php $__errorArgs = ['Data Type Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

                    <div class="form-group row mb-0">
                        <div class="col-md-2 offset-md-2">
                            <button type="submit" id="btun1"class="btn btn-primary">
                                <?php echo e(__('Add')); ?>

                            </button>
                            <button id="btun2"  class="btn btn-primary">
                                <a href="<?php echo e(url('/Property_Details_show')); ?>" class="link2" ><?php echo e(__('Show')); ?></a>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="x_panel">
                <div id="datatable_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap no-footer">
                    <div class="row">
                    </div>
                    <?php echo $__env->yieldContent('Property_Details_table'); ?>

                    <div class="row">
                    </div>
                </div>
            </div>

        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GP\realEstate\resources\views/website/backend/database pages/Property_Details.blade.php ENDPATH**/ ?>