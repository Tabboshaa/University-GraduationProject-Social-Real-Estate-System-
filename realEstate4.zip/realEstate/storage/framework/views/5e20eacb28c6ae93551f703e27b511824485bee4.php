
<?php $__env->startSection('content'); ?>

<link href="<?php echo e(asset('css/ButtonStyle.css')); ?>" rel="stylesheet" type="text/css" />
<script>
    function searchForItems() {

        var item_id = $("#Item").val();
        var flag=false;
        $("#submitbtn").prop("disabled", true);
        $("#submitbtn").html('See Item');
        $("#submitbtn").removeClass('btn btn-danger').addClass('btn btn-primary');
        $("#next_button").html('');

        $('option[name="items_options"]').each(function() {
            if (item_id == this.value) {
                flag=true;
                $("#next_button").html('Item Found');
                $("#submitbtn").removeAttr("disabled");
                    return true;
            }
        });
        if(!flag){
        $("#submitbtn").html('Item not Found');
        $("#submitbtn").removeClass('btn btn-primary').addClass('btn btn-danger');
        }
    }
    function changesearch(){ 
        searchForItems();
        // $("#submitbtn").prop("disabled", true);
        }
</script>

<div class="right_col" role="main">
    <div class="title_right">
        <div class="x_panel">
            <?php echo $__env->make('website.backend.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Item -->
            <form method="Get" action="<?php echo e(url('/ShowItem')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

            <div class="form-group row">
                <label for="Item" class="col-md-2 col-form-label text-md-right">
                    <?php echo e(__('Item')); ?>

                </label>
                <div class="col-md-2">
                    <input type="search" id="Item" list="items" class="form-control <?php $__errorArgs = ['Item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Item" value="<?php echo e(old('Item')); ?>" required autocomplete="Item" onchange="changesearch()">
                    <!--  For loop  -->
                    <div id="next_button" ></div>
                 <datalist id="items">
                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->Item_Id); ?>" name="items_options"><?php echo e($item->Item_Id); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>
                    <!-- End loop -->
                    </select>
                    <?php $__errorArgs = ['Item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group row mb-0">
                <div class="col-md-2 offset-md-2">
                    <!-- <a href="javascript:void(0)" class="btn btn-primary" onclick="searchForItems()">
                        <?php echo e(__('Search')); ?>

                    </a> -->
            
                    <button  class="btn btn-primary" type="submit" disabled id="submitbtn">
                        <?php echo e(__('See Item')); ?>

                    </button>
                </div>
            </div>
            </form>
        </div>
        <div class="x_panel">
            <div id="datatable_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap no-footer">
                <div class="row">
                </div>
                <?php echo $__env->yieldContent('Details_table'); ?>

                <div class="row">
                </div>
            </div>
        </div>

    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GP\realEstate\resources\views/website/backend/database pages/Details.blade.php ENDPATH**/ ?>