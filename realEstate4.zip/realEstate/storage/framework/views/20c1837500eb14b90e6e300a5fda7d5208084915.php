
<?php $__env->startSection('Item_Main_Type_table'); ?>

<link href="<?php echo e(asset('css/ItemStyle.css')); ?>" rel="stylesheet" type="text/css" />
    <div class="x_panel">
        <div class="x_title">
            
            <h2 style="text-align: center">New Item</h2>
            <div class="clearfix"></div>
        
        </div>
            <!-- EL MAIN FOREARCH HNA -->
            <?php $__currentLoopData = $main_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4">
                    <table id="datatable" class="table table-striped table-bordered dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="datatable_info">
                        <thead>
                            <th><h6><?php echo e($main->Main_Type_Name); ?></h6></th>
                        </thead>

                        <tbody>
                        <!-- EL SUB FOREARCH HNA -->
                            <?php $__currentLoopData = $sub_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($sub->Main_Type_Id == $main->Main_Type_Id): ?>
                                    <tr><td><a href="<?php echo e(url('property_select/'.$item_id.'/'.$sub->Sub_Type_Id)); ?>"><?php echo e($sub->Sub_Type_Name); ?></a></td></tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.backend.database pages.Item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GP\realEstate\resources\views/website/backend/database pages/Item_Sub_Type_Show.blade.php ENDPATH**/ ?>