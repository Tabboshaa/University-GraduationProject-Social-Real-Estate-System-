<?php $__env->startSection('table'); ?>
<div class="row">
    <div class="col-sm-12">
        <table id="datatable" class="table table-striped table-bordered dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="datatable_info">
            <thead>
                <tr>
                    <th>Main Type ID</th>
                    <th>Sub Type Name</th>
                    <th>Select all <input type="checkbox" id="selectAll" name="selectAll"> <a href="/delete_sub_type">  </a></th>
                    <th></th>
                    <!-- Java Script for select all function -->
                    <script>
                        document.getElementById('selectAll').onclick = function() {
                            var checkboxes = document.getElementsByName('id[]'); //get all check boxes with name delete
                            for (var checkbox of checkboxes) { //for loop to set all checkboxes to checked
                                checkbox.checked = this.checked;
                            }
                        }
                    </script>
                </tr>
            </thead>
            <tbody>

                <!-- EL FOREARCH HNA -->
                <?php $__currentLoopData = $sub_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <form method="Post" action="<?php echo e(url('/delete_sub_type/'.$sub_type->Sub_Type_Id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                    <tr>
                    <td><?php echo e($sub_type->Main_Type_Name); ?></td>
                    <td><?php echo e($sub_type->Sub_Type_Name); ?></td>
                    <td><input type="checkbox" name="id[]" value="<?php echo e($sub_type->Sub_Type_Id); ?>"></td>
                    <input type="hidden" name="_method" value="DELETE">
                        <td><a href="javascript:void(0)" onclick="setSupTypeIdName('<?php echo e($sub_type->Sub_Type_Id); ?>','<?php echo e($sub_type->Sub_Type_Name); ?>')"><i class="fa fa-edit"> Edit</i></a></td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <td><input type="submit" value="Delete Selected"></td>
                    </form>
                <!-- END OF FOREACH -->

            </tbody>
        </table>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="EditSubTypeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Sub Type</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="EditSubTypeForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="id">
                    <div>
                    <label for="MainTypeNameEdit">Main Type Name</label>
                        <select id="MainTypeNameEdit" class="form-control"  name="MainTypeNameEdit">
                            <!--  For loop  -->
                            <?php $__currentLoopData = $main_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($main->Main_Type_Id); ?>"><?php echo e($main->Main_Type_Name); ?></option> 
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- End loop -->
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="SubTypeName" >Sub Type Name</label>
                        <input type="text" name="SubTypeName" id="SubTypeName" class="form-control">
                    </div>
                    <button  type="submit" class="btn btn-success">Edit</button>
                </form>

            </div>
        </div>
    </div>
</div>

    <script>
        function setSupTypeIdName(id,name){

                $("#id").val(id);
                $("#SubTypeName").val(name);
                $("#EditSubTypeModal").modal("toggle");
        }
        $('#EditSubTypeForm').submit(function (){

            var id=$("#id").val();
            var MainTypeid=$("#MainTypeNameEdit").val();
            var SupTypeName=$("#SubTypeName").val();
            var _token= $("input[name=_token]").val();
            
            $.ajax({
                url:"<?php echo e(route('suptype.update')); ?>",
                Type:"PUT",
                data:{
                    id:id,
                    MainTypeid:MainTypeid,
                    SupTypeName:SupTypeName,
                     _token:_token
                },
                success:function (response){
                    console.log('Success')
                    console.log(response);
                    $('#sid'+response.id + 'td:nth-child(1)').text(response.SupTypeName);
                    $("#EditSubTypeModal").modal("toggle");
                    // $("#EditSubTypeModal")[0].reset();
                },
                error:function ()
                {
                    console.log('Error');
                }

            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.backend.database pages.Sub_Type', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realEstate\resources\views/website/backend/database pages/Sub_Types_Show.blade.php ENDPATH**/ ?>