
<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="title_right">
            <div class="x_panel">
                <form method="POST" action="<?php echo e(url('/Create_Country')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <!-- Add New Country -->
                    <div class="form-group row">
                     <label for="country_name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Country Name :')); ?></label>
                      <div class="col-md-2">
                       <input id="country_name" type="text" class="form-control <?php $__errorArgs = ['country_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="country_name" value="<?php echo e(old('country_name')); ?>" required autocomplete="country_name" autofocus>

                            <?php $__errorArgs = ['country_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      
                      </div>
                    </div>
                    <div class="form-group row mb-0">
                        <div class="col-md-2 offset-md-2">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Add')); ?>

                            </button>
                            <a href="<?php echo e(url('/show_country')); ?>" class="btn btn-primary"><?php echo e(__('Show')); ?></a>
                        </div>
                    </div>

        
                </form>
            </div>
            <div class="x_panel">
            <div id="datatable_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap no-footer">
                <div class="row">
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <?php echo $__env->yieldContent('table'); ?>
                    </div>
                </div>
                <div class="row">
                </div>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realEstate\resources\views/website\backend/database pages/Add_Country.blade.php ENDPATH**/ ?>