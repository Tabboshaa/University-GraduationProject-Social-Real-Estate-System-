
<?php $__env->startSection('Property_Details_table'); ?>
<link href="<?php echo e(asset('css/hamada.css')); ?>" rel="stylesheet" type="text/css" />

<link href="<?php echo e(asset('css/ShowStyle.css')); ?>" rel="stylesheet" type="text/css" />

<div class="x_title">
    <h2>All Details</h2>

    <div class="clearfix"></div>
</div>

<div class="row">
    <div class="col-sm-12">
        <form method="Post" action="<?php echo e(url('/delete_property_detail?_method=delete')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." title="Type in a name">
            <table id="datatable" class="table table-bordered dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="datatable_info">
                <thead>
                    <tr>
                    <tr>
                        <th><h2 style="margin-right:10px; padding-bottom: 5px;">Main Type ID</h2></th>
                        <th ><h2 style="margin-right:10px;padding-bottom: 5px;">Sub Type Name</h2></th>
                        <th ><h2 style="margin-right:10px;padding-bottom: 5px;">Sub Type Property</h2></th>
                        
                        <th> <h2 style="margin-right:10px;padding-bottom: 5px;">Property Detail Name</th>
                        <th> <h2 style="margin-right:10px;padding-bottom: 5px;">Data Type</th>
                        <th ><h2 style="margin-right:10px;padding-bottom: 5px;">Edit</h2></th>
                        <th >Select all <input type="checkbox" id="selectAll" name="selectAll">  <button class="btn"><i class="fa fa-trash" style="margin-right:10px;"></i></th>
                        <!-- Java Script for select all function -->
                        <script>
                            document.getElementById('selectAll').onclick = function() {
                                var checkboxes = document.getElementsByName('id[]'); //get all check boxes with name delete
                                for (var checkbox of checkboxes) { //for loop to set all checkboxes to checked
                                    checkbox.checked = this.checked;
                                }
                            }
                        </script>
                    </tr>
                </thead>
                <tbody>
                    <!-- EL FOREARCH HNA -->
                    <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($property_detail->Main_Type_Name); ?></td>
                        <td><?php echo e($property_detail->Sub_Type_Name); ?></td>
                        <td><?php echo e($property_detail->Property_Name); ?></td>
                        <td><?php echo e($property_detail->Detail_Name); ?></td>
                        <td><?php echo e($property_detail->datatype); ?></td>
                        
                        <td><a href="javascript:void(0)" onclick="setPropertyDetailIdName('<?php echo e($property_detail->Property_Detail_Id); ?>','<?php echo e($property_detail->Detail_Name); ?>')"><i class="fa fa-edit"></i></a></td>
                        <td><input type="checkbox" name="id[]" value="<?php echo e($property_detail->Property_Detail_Id); ?>"></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- END OF FOREACH -->
                </tbody>
            </table>
            <?php echo $property->render(); ?>

        </form>
    </div>
</div>
<div class="modal fade" id="EditPropertyDetailModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Property Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="EditSubTypeForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="id">

                    <div class="form-group">
                        <label for="PropertyDetailName" style="font-size: 12pt" >Detail </label>
                        <input type="text" style="border-radius: 3pt" name="PropertyDetailName" id="PropertyDetailName" class="form-control">
                    </div>
                    <button type="submit" id="btun3" class="btn btn-success">Edit</button>
                </form>

            </div>
        </div>
    </div>
</div>

<script>
 function myFunction() {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("myInput");
        filter = input.value.toUpperCase();
        table = document.getElementById("datatable");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[3];
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    }
    function setPropertyDetailIdName(id, name) {

        $("#id").val(id);
        $("#PropertyDetailName").val(name);
        $("#EditPropertyDetailModal").modal("toggle");
    }
    $('#EditSubTypeForm').submit(function() {

        var id = $("#id").val();
        // var MainTypeid=$("#MainTypeNameEdit").val();
        var PropertyDetailName = $("#PropertyDetailName").val();
        var _token = $("input[name=_token]").val();

        $.ajax({
            url: "<?php echo e(route('propertyDetail.update')); ?>",
            Type: "PUT",
            data: {
                id: id,
                // MainTypeid:MainTypeid,
                PropertyDetailName: PropertyDetailName,
                _token: _token
            },
            success: function() {
                console.log('Success');
                // $('#sid'+response.id + 'td:nth-child(1)').text(response.PropertyDetailName);
                $("#EditPropertyDetailModal").modal("toggle");
                // $("#EditPropertyDetailModal")[0].reset();
            },
            error: function() {
                console.log('Error');
            }

        });
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.backend.database pages.Property_Details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GP\realEstate\resources\views/website/backend/database pages/Property_Details_Show.blade.php ENDPATH**/ ?>