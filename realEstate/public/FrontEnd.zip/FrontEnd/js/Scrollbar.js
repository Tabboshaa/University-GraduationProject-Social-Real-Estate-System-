 (function($){
    $(window).on("load",function(){
        $(".chat-hist, .messages-line").mCustomScrollbar();
         axis:"yx"
    });
})(jQuery);